package tools;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaseDao {
	/**
	 * ������ݿ�
	 * 
	 * @return
	 */
	public Connection getCon() {
		String className = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		String url = "jdbc:sqlserver://127.0.0.1:1433;databaseName=exam";
		Connection con = null;
		try {
			// 1.������
			Class.forName(className);
			// 2.��������
			con = DriverManager.getConnection(url, "sa", "123");
			return con;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("������ݿ�ʧ��:1.��ݿ��Ƿ�����? 2.���Ӳ����Ƿ���ȷ?");
		}
	}

	/**
	 * ִ�в�ѯ�����ض��н��List<Map>
	 * 
	 * @param sql
	 * @param parms
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public List<Map> getList(String sql, Object[] parms) {
		List<Map> list = new ArrayList<Map>();
		Connection con = getCon();
		PreparedStatement st = null;
		ResultSet rs = null;
		try {
			st = con.prepareStatement(sql);
			if (parms != null) {
				for (int i = 0; i < parms.length; i++) {
					st.setObject(i + 1, parms[i]);
				}
			}
			rs = st.executeQuery();
			int colCnt = rs.getMetaData().getColumnCount();
			String colName = null;
			Object value = null;
			while (rs.next()) {
				Map row = new HashMap();
				for (int i = 1; i <= colCnt; i++) {
					value = rs.getObject(i);
					colName = rs.getMetaData().getColumnName(i);
					row.put(colName, value);
				}
				list.add(row);
			}
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ִ�в�ѯ����:" + sql);
			throw new RuntimeException(e);
		} finally {
			closeAll(rs, st, con);
		}
	}

	/**
	 * ִ�в�ѯ,���ص���ֵ
	 * 
	 * @param sql
	 * @return
	 */
	public Object getValue(String sql) {
		Connection con = getCon();
		PreparedStatement st = null;
		ResultSet rs = null;
		try {
			st = con.prepareStatement(sql);
			rs = st.executeQuery();
			if (rs.next()) {
				return rs.getObject(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("ִ�в�ѯ����:" + sql);
			throw new RuntimeException(e);
		} finally {
			closeAll(rs, st, con);
		}
		return null;
	}

	/**
	 * ִ����ɾ��SQL
	 * 
	 * @param sql
	 */
	public boolean update(String sql, Object[] parms) {
		Connection con = getCon();
		PreparedStatement st = null;
		boolean bool = true;
		try {
			st = con.prepareStatement(sql);
			if (parms != null) {
				for (int i = 0; i < parms.length; i++) {
					st.setObject(i + 1, parms[i]);
				}
			}
			st.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ִ���޸ĳ���:" + sql);
			bool = false;
			throw new RuntimeException(e);
		} finally {
			closeAll(null, st, con);
		}
		return bool;
	}

	public void closeAll(ResultSet rs, Statement st, Connection con) {
		try {
			if (rs != null)
				rs.close();
		} catch (SQLException e1) {
		}
		try {
			if (st != null)
				st.close();
		} catch (SQLException e) {
		}
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
		}
	}

	public static void main(String[] args) throws Exception {
		BaseDao bs = new BaseDao();
		System.out.println(bs.getCon());
		// List<Map> list=new
		// BaseDao().getList("select * from sysobjects",null);
		// for (Map map : list) {
		// Collection row=map.values();
		// for (Object v : row) {
		// System.out.print(v+"\t");
		// }
		// System.out.println();
		// }

		// Object v=new BaseDao().getValue("select count(*) from sysobjects");
		// System.out.println((Integer)v);
	}
}
