package com.qhit.dao;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.BaseDao;
import tools.HibernateSessionFactory;

import com.qhit.domain.Question;



public class QuestionDAO {
	public List<Question> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Question> questionList = session.createCriteria(Question.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questionList;
	}
	//,String content,String optionA,String optionB,String optionC,String optionD
	public void save(String kind){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		Question question = new Question();
		question.setKind(kind);
		//question.setContent(content);
		//question.setAnswer(answer);
		session.save(question);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
	public List<Map> slist(){
		BaseDao dao = new BaseDao();
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		String sql = "select q.subjectId from question q group by q.subjectId " ;
		List<Map> subList = dao.getList(sql, null);
		System.out.println(subList);
		//List<Question> subList = session.createCriteria(sql).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return subList;
	}
	public List<Question> sslist(String subjectId)
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		String sql = "select * from question where subjectId='"+subjectId+"'";
		List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return questionList;
	}
	//select * from question group by '"+subjectId+"'
	public static void main(String[] args) {
		QuestionDAO dao = new QuestionDAO();
		dao.slist();
	}
}
