package com.qhit.action;

import com.opensymphony.xwork2.Action;

public class StudentAction implements Action{

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
