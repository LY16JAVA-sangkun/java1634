package com.qhit.action;

import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.TeacherDAO;
import com.qhit.domain.Teacher;

public class TeacherAction implements Action {

	private Teacher teacher;
	private String tname;
	private String taccount;
	
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTaccount() {
		return taccount;
	}
	public void setTaccount(String taccount) {
		this.taccount = taccount;
	}
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private List<Teacher> teacherList;
	
	public List<Teacher> getTeacherList() {
		return teacherList;
	}
	public void setTeacherList(List<Teacher> teacherList) {
		this.teacherList = teacherList;
	}
	public String list()
	{
		System.out.println("aa");
		TeacherDAO tdao = new TeacherDAO();
		teacherList = tdao.list();
		System.out.println(teacherList.size());
		return "list";
	}
	public String up(){
		HttpServletResponse response = null;
		HttpServletRequest request = null;
		request = ServletActionContext.getRequest();
		response = ServletActionContext.getResponse();
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("text/html;charset = utf-8");
		Session session =HibernateSessionFactory.getSession();
		Transaction transaction= session.beginTransaction();
		System.out.println(id);
		teacher=(Teacher) session.get(Teacher.class, id);
		System.out.println(teacher);
	    transaction.commit();
	    session.close();
		return "up";
	}
	public String update(){
		HttpServletResponse response = null;
		HttpServletRequest request = null;
		request = ServletActionContext.getRequest();
		response = ServletActionContext.getResponse();
		try {
			request.setCharacterEncoding("utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("text/html;charset = utf-8");
		TeacherDAO dao = new TeacherDAO();
		dao.update(teacher.getId(),teacher.getTname(), teacher.getTaccount());
		return SUCCESS;
	}
//	<--!book.do?method=edit&id=${teacher.id}
//	book.do?method=delete&id=${user.id}!-->
	
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
}
