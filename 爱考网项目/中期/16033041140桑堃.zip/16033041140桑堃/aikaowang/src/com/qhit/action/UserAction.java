package com.qhit.action;

import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.hibernate.Transaction;



import tools.HibernateSessionFactory;

import com.opensymphony.xwork2.Action;
import com.qhit.domain.User;

import tools.BaseDao;

public class UserAction implements Action{

	private User user;
	
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String login(){
		BaseDao dao = new BaseDao();
		if (user.getRole().equals("1")) {
			//System.out.println(user.getPwd());
			if (!user.getPwd().equals("")) {
				String name = user.getName();
				String sql = "select stuNo from student where stuNo = '"+name+"' ";
				//dao.getList(sql, null);
				List<Map> list = dao.getList(sql, null);
				if (list.size()!=0) {
					System.out.println(user.getName());
					ServletActionContext.getRequest().getSession().setAttribute("user", user.getName());
					return "login";
				}
			}
			 
		} else if(user.getRole().equals("2")) {
			if (!user.getPwd().equals("")) {
			String name = user.getName();
			String sql = "select taccount from teacher where taccount = '"+name+"' ";
			//dao.getList(sql, null);
			List<Map> list = dao.getList(sql, null);
			if (list.size()!=0) {
				ServletActionContext.getRequest().getSession().setAttribute("user", user.getName());
				return "login";
			}
			}
		} else if (user.getRole().equals("4")) {
			if (!user.getPwd().equals("")) {
			String name = user.getName();
			String sql = "select aname from admin where aname = '"+name+"' ";
			//dao.getList(sql, null);
			List<Map> list = dao.getList(sql, null);
			if (list.size()!=0) {
				ServletActionContext.getRequest().getSession().setAttribute("user", user.getName());
				return "login";
			}
			}
		}
		return "index";
	}
}
