package com.qhit.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.qhit.domain.Teacher;

import tools.HibernateSessionFactory;

public class TeacherDAO {
	
	public List<Teacher> list()
	{
		
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		
		List<Teacher> teacherList = session.createCriteria(Teacher.class).list();
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return teacherList;
	}

		public void update(int id,String tname,String taccount){
			//Users users = new Users();
			System.out.println("456");
			Session session =  HibernateSessionFactory.getSession();
			
			Teacher teacher = (Teacher) session.get(Teacher.class, id);
			teacher.setTname(tname);
			teacher.setTaccount(taccount);
			session.update(teacher);
			Transaction transaction = session.beginTransaction();
			transaction.commit();
			//HibernateSessionFactory.closeSession();
		}
	public static void main(String[] args) {
		TeacherDAO dao =new TeacherDAO();
		dao.update(1,"桑坤","1445412");
	}
}
