package com.qhit.action;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.QuestionDAO;
import com.qhit.dao.TeacherDAO;
import com.qhit.domain.Question;

public class QuestionAction implements Action{

	private List<Map> sublist;
	private String subjectId;

	public String getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(String subjectId) {
		this.subjectId = subjectId;
	}

	public List<Map> getSublist() {
		return sublist;
	}

	public void setSublist(List<Map> sublist) {
		this.sublist = sublist;
	}

	private Question question;
	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	private List<Question> questionlist;
	
	
	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public String list(){
		System.out.println("aa");
		QuestionDAO tdao = new QuestionDAO();
		questionlist = tdao.list();
		System.out.println(questionlist.size());
		sublist = tdao.slist();
		//System.out.println(questionlist.size());
		return "list";	
	}
	
	public String save(){
		System.out.println("123");
		QuestionDAO dao = new QuestionDAO();
		dao.save(question.getKind());
		//, content, optionA, optionB, optionC, optionD
		return "save";
	}
	public String sublist(){
		System.out.println("bb");
		System.out.println(subjectId);
		QuestionDAO tdao = new QuestionDAO();
		questionlist = tdao.sslist(subjectId);
		sublist = tdao.slist();
		System.out.println(questionlist.size());
		return "list";	
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
