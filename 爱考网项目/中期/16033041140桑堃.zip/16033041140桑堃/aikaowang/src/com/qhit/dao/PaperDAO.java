package com.qhit.dao;

import java.util.List;
import java.sql.Timestamp;

import org.hibernate.Session;
import org.hibernate.Transaction;

import tools.HibernateSessionFactory;

import com.qhit.domain.Question;
import com.qhit.domain.paper;

public class PaperDAO {

	public List<paper> list()
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		List<paper> paperlist = session.createCriteria(paper.class).list();
		for (paper paper : paperlist) {
			System.out.println(paper.toString());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperlist;
	}
	public List<paper> slist(int pid)
	{
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		String sql = "select * from paper where pid = '"+pid+"'";
		List<paper> paperlist = session.createSQLQuery(sql).addEntity(paper.class).list();
		for (paper paper : paperlist) {
			System.out.println(paper.getQset());
		}
		transaction.commit();
		HibernateSessionFactory.closeSession();
		return paperlist;
	}
	public void save(String title,int acount,int bcount,String subjectName,String kind,String state,Timestamp testTime,Integer testHour, Double totalScore,String className){
		Session session = HibernateSessionFactory.getSession();
		Transaction transaction =session.beginTransaction();
		paper paper = new paper();
		int a = acount +bcount;
		paper.setTitle(title);
		paper.setSubjectName(subjectName);
		paper.setKind(kind);
		paper.setState(state);
		paper.setTestTime(testTime);
		paper.setTestHour(testHour);
		paper.setTotalScore(totalScore);
		paper.setClassName(className);
		paper.setQnumber(a);
		String sql = "select q.* from (select top" +
		" "+acount+" * from question where difficulty= " +
		"'简单'  order by newId() " +
		"union select top "+bcount+" *  " +
		"from question where difficulty= " +
		"'困难' order by newId()) as q";
		List<Question> questionList = session.createSQLQuery(sql).addEntity(Question.class).list();	
		for (Question question : questionList) {
			System.out.println(question);
			paper.getQset().add(question);
		}
		session.save(paper);
		transaction.commit();
		HibernateSessionFactory.closeSession();
	}
}
