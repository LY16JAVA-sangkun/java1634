package com.qhit.action;

import java.util.List;

import com.opensymphony.xwork2.Action;
import com.qhit.dao.PaperDAO;
import com.qhit.dao.QuestionDAO;
import com.qhit.domain.Question;
import com.qhit.domain.paper;

public class PaperAction implements Action {

	private int pid;
	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}
	private int acount;
	private int bcount;
	private List<Question> questionlist;
	
	
	public List<Question> getQuestionlist() {
		return questionlist;
	}

	public void setQuestionlist(List<Question> questionlist) {
		this.questionlist = questionlist;
	}

	public int getAcount() {
		return acount;
	}

	public void setAcount(int acount) {
		this.acount = acount;
	}

	public int getBcount() {
		return bcount;
	}

	public void setBcount(int bcount) {
		this.bcount = bcount;
	}
	private Question question;
	public Question getQuestion() {
		return question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}
	private paper paper;
	
	public paper getPaper() {
		return paper;
	}

	public void setPaper(paper paper) {
		this.paper = paper;
	}
	private List<paper> paperlist;
	
	public List<paper> getPaperlist() {
		return paperlist;
	}

	public void setPaperlist(List<paper> paperlist) {
		this.paperlist = paperlist;
	}

	public String list(){
		System.out.println("aa");
		PaperDAO tdao = new PaperDAO();
		paperlist = tdao.list();
		System.out.println(paperlist.size());
		return "list";	
	}
	public String slist(){
		System.out.println(pid);
		PaperDAO dao = new PaperDAO();
		paperlist= dao.slist(pid);
		return "list";
		}
	public String save(){
		PaperDAO dao = new PaperDAO();
		dao.save(paper.getTitle(),acount, bcount,paper.getClassName(),paper.getKind(),paper.getState(),paper.getTestTime(),paper.getTestHour(),paper.getTotalScore(),paper.getSubjectName());
		return "save";
	}
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
